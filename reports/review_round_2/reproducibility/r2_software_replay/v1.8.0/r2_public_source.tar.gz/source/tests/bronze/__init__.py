"""Bronze release tests."""
