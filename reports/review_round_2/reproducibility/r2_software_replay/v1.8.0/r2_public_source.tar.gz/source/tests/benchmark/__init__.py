"""Extraction benchmark tests."""
