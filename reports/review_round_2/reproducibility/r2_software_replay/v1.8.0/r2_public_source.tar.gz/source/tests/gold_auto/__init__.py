"""Gold-auto tests."""
