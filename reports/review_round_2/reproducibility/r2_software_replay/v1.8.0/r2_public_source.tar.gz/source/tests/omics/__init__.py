"""PRIDE triage tests."""
