"""Coverage audit tests."""
