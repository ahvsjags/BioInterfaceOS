"""Silver release tests."""
